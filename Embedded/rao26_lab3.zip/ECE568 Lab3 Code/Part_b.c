

# include "msp430f5438a.h"

int counter =0,i=0,j=0;

int val1, val2;

char message1[10] = "X=";

char message2[10] = "Y=";

int main(){

	WDTCTL = WDTPW | WDTHOLD;	// Stop watchdog timer
	P5SEL |= BIT6 + BIT7; // setting for UART communication
	UCA1CTL1 |= UCSWRST+ UCSSEL__SMCLK; // Reset and set to SMCLK

	// setting Baud Rate UCBRx =9 // Baud rate of 115200
	UCA1BR0 = 9;
	UCA1BR1 = 0;  // from Datasheet

	// Setting UCBRS0
	UCA1MCTL |= UCBRS1 + UCBRF_0;

	UCA1CTL1 &= ~UCSWRST; // First state

	// UCA1IE |= UCRXIE + UCTXIE; // Enable transmit and receive interrupts

	 __bis_SR_register(GIE); // Enable global interrupts

	  // UCA1TXBUF = count; // setting the value of the transmit register to count

	 //Configure switch S1 and S2
	     	P2SEL &= 0x3F ;//I/O Function 0011 1111=0x3F
	     	P2DIR &= 0x3F; //P2.6 as input
	     	P2REN |= 0xC0; //Enable pull resistor
	     	P2OUT |= 0xC0; //Enable Pull-Up resistor
	     	P2IE |=  0xC0;   // Enable Port 2 interrupt registers

	    // Configure Accelerometer and ADC
	     		     	  P6SEL |= 0x06;                            // P6.1  and P 6.2 ADC option select
	     		     	  P6DIR |= 0x01;                            // P6.0 output -- power to Accelero
	     		     	  P6OUT |=0x01;                             // Switch on the Accelerometer

	  // Configure ADC

	     	UCSCTL8 |= MODOSCREQEN;      // need to figure
	     	  ADC12CTL0 = ADC12SHT02 + ADC12ON + ADC12MSC ;         // Sampling time, ADC12 on , Enable Multiple conversion
	     	  ADC12CTL1 = ADC12SHP + ADC12CONSEQ_1 + ADC12SSEL_0;                     // Use sampling timer

	     	  ADC12MCTL0 = ADC12INCH_1; // get X value
	     	  ADC12MCTL1 = ADC12INCH_2; // get Y value

	     	while(1);
}

# pragma vector=ADC12_VECTOR
__interrupt void ADC12_ISR(void){
	switch(ADC12IV){

	case 6:    ADC12IE &=0x0000;
				val1 = ADC12MEM0;
				(((val1/256)%16)<9) ?  ( message1[3] = ((val1/256)%16)+ 48 ) : ( message1[3] = ((val1/256)%16)+ 55 );
				(((val1/16)%16)<9) ?  ( message1[4] =  ((val1/16)%16)+ 48 ) :  ( message1[4] =  ((val1/16)%16)+ 55 );
				((val1%16)<9) ? ( message1[5] =  (val1%16)+ 48) : ( message1[5] = (val1%16)+ 55 );
				message1[6] =  ' ';
				message1[7] =  ' ';
				message1[8] = '\0';
 						for(j=0;j<9;j++){
						UCA1TXBUF = message1[j];
						while(!(UCA1IFG & UCTXIFG));
						}
				break;

	case 8:    ADC12IE &=0x0000;
				val2 = 	ADC12MEM1;
				(((val2/256)%16)<9) ? message2[3] = ( ((val2/256)%16)+ 48 ) : ( message2[3] = ((val2/256)%16)+ 55 );
				(((val2/16)%16) <9) ? message2[4] = ( ((val2/16)%16)+ 48 ) : ( message2[4] =  ((val2/16)%16)+ 55 );
				((val2%16)<9) ?  ( message2[5] =  (val2%16)+ 48 ) : ( message2[5] = (val2%16)+ 55 );
				message2[6] =  ' ';
				message2[7] =  ' ';
				message2[8] = '\0';
					for(j=0;j<9;j++){
						UCA1TXBUF = message2[j];
						while(!(UCA1IFG & UCTXIFG));
					}
				break;

	}
}
  #pragma vector=PORT2_VECTOR
__interrupt void PORT2_ISR(void)  {

	for(i=0;i<30000;i++); // makeshift debouncer

	switch (P2IV){

	case (P2IV_P2IFG6) :  ADC12IE |= 0x0001;                           // Enable interrupt on 0 -- IFG0  flag
						  ADC12CTL0 |= ADC12ENC + ADC12SC ;    break;

	case(P2IV_P2IFG7):    ADC12IE |= 0x0002;                           // Enable interrupt on 1 -- IFG1  flag
						ADC12CTL0 |= ADC12ENC + ADC12SC ;    break;
		}
}
// UCA0ICTL;

