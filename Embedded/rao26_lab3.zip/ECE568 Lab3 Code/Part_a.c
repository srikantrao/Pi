/*
 * UART_Interface.c
 *
 *  Created on: Feb 22, 2014
 *      Author: ece49542
 */

# include "msp430f5438a.h"

int i =0,j=0;

  char count = '5'; // set a global variable
  const char warning[13] = "OUT OF RANGE";
int main(){

	WDTCTL = WDTPW | WDTHOLD;	// Stop watchdog timer
	P5SEL |= BIT6 + BIT7; // setting for UART communication
	UCA1CTL1 |= UCSWRST+ UCSSEL__SMCLK; // Reset and set to SMCLK

	// setting Baud Rate UCBRx =9 // Baud rate of 115200
	UCA1BR0 = 9;
	UCA1BR1 = 0;  // from Datasheet

	// Setting UCBRS0
	UCA1MCTL |= UCBRS1 + UCBRF_0;

	UCA1CTL1 &= ~UCSWRST; // First state

	// UCA1IE |= UCRXIE + UCTXIE; // Enable transmit and receive interrupts

	 __bis_SR_register(GIE); // Enable global interrupts


	 UCA1TXBUF = count; // setting the value of the transmit register to count


	 //Configure switch S1 and S2
	     	P2SEL &= 0x3F ;//I/O Function 0011 1111=0x3F
	     	P2DIR &= 0x3F; //P2.6 as input
	     	P2REN |= 0xC0; //Enable pull resistor
	     	P2OUT |= 0xC0; //Enable Pull-Up resistor
	     	P2IE |=  0xC0;   // Enable Port 2 interrupt registers

	     	while(1);
}

// UART interrupt that needs to be used

/*  #pragma vector=USCI_A0_VECTOR
__interrupt void USCI_A0_ISR(void){
	switch(__even_in_range(UCA0IV,18)) {
	case 0x00: break;
	case 0x02:
	break;
	case 0x04:
	break;
	default: break;
	}
} */

  #pragma vector=PORT2_VECTOR
__interrupt void PORT2_ISR(void)  {

	for(i=0;i<30000;i++); // makeshift debouncer

	switch (P2IV){

	case (P2IV_P2IFG6) : if (count > (0x30)){  UCA1TXBUF = --count;}
						else if(count=='0') {
											for(j=0;warning[j]!='\0';j++){
								     		UCA1TXBUF = warning[j];

								     		while(!(UCA1IFG & UCTXIFG));
								     	}

						}
						break;

	case(P2IV_P2IFG7): if(count < (0x39) ) {UCA1TXBUF = ++count;}
					  else if(count =='9') {
						  	  	  	  	for(j=0;warning[j]!='\0';j++){
						  	     		UCA1TXBUF = warning[j];
						  	     		while(!(UCA1IFG & UCTXIFG));
						  	     	}


					  }
						break;

	}
}
// UCA0ICTL;
