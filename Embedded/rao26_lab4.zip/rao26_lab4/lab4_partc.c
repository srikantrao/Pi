#include "lcd.h"
#include "msp430f5438a.h"
#include "hal_lcd_fonts.h"

unsigned char LcdInitMacro[] = {
    0x74, 0x00, 0x00, 0x76, 0x00, 0x01,            // R00 start oscillation
    0x74, 0x00, 0x01, 0x76, 0x00, 0x0D,            // R01 driver output control
    0x74, 0x00, 0x02, 0x76, 0x00, 0x4C,            // R02 LCD - driving waveform control
    0x74, 0x00, 0x03, 0x76, 0x12, 0x14,            // R03 Power control
    0x74, 0x00, 0x04, 0x76, 0x04, 0x66,            // R04 Contrast control
    0x74, 0x00, 0x05, 0x76, 0x00, 0x10,            // R05 Entry mode
    0x74, 0x00, 0x06, 0x76, 0x00, 0x00,            // R06 RAM data write mask
    0x74, 0x00, 0x07, 0x76, 0x00, 0x15,            // R07 Display control
    0x74, 0x00, 0x08, 0x76, 0x00, 0x03,            // R08 Cursor Control
    0x74, 0x00, 0x09, 0x76, 0x00, 0x00,            // R09 RAM data write mask
    0x74, 0x00, 0x0A, 0x76, 0x00, 0x15,            // R0A
    0x74, 0x00, 0x0B, 0x76, 0x00, 0x03,            // R0B Horizontal Cursor Position
    0x74, 0x00, 0x0C, 0x76, 0x00, 0x03,            // R0C Vertical Cursor Position
    0x74, 0x00, 0x0D, 0x76, 0x00, 0x00,            // R0D
    0x74, 0x00, 0x0E, 0x76, 0x00, 0x15,            // R0E
    0x74, 0x00, 0x0F, 0x76, 0x00, 0x03,            // R0F
    0x74, 0x00, 0x10, 0x76, 0x00, 0x15,            // R0E
    0x74, 0x00, 0x11, 0x76, 0x00, 0x03,            // R0F
};

unsigned char Read_Block_Address_Macro[] = {0x74, 0x00, 0x12, 0x77, 0x00, 0x00};
unsigned char Draw_Block_Value_Macro[] = {0x74, 0x00, 0x12, 0x76, 0xFF, 0xFF};
unsigned char Draw_Block_Address_Macro[] = {0x74, 0x00, 0x11, 0x76, 0x00, 0x00};

unsigned int val1, val2;
char message1[10] = "X=";
char message2[10] = "Y=";

unsigned int LcdAddress = 0, LcdTableAddress = 0;

 // int LCD_MEM[110 * 17];

void halLcdSendCommand(unsigned char Data[])
{
    unsigned char i;

    LCD_CS_RST_OUT &= ~LCD_CS_PIN;                 //CS = 0 --> Start Transfer
    for (i = 0; i < 6; i++)
    {
        while (!(UCB2IFG & UCTXIFG)) ;             // Wait for TXIFG
        UCB2TXBUF = Data[i];                       // Load data

        if (i == 2)                                //Pull CS up after 3 bytes
        {
            while (UCB2STAT & UCBUSY) ;
            LCD_CS_RST_OUT |= LCD_CS_PIN;          //CS = 1 --> Stop Transfer
            LCD_CS_RST_OUT &= ~LCD_CS_PIN;         //CS = 0 --> Start Transfer
        }
    }
    while (UCB2STAT & UCBUSY) ;
    LCD_CS_RST_OUT |= LCD_CS_PIN;                  //CS = 1 --> Stop Transfer
}

void halLcdActive(void)
{
    halLcdSendCommand(LcdInitMacro);         // R00 start oscillation

    // Wait a minimum of 25ms after issuing "start oscillation"
    // command (to accomodate for MCLK up to 25MHz)
    __delay_cycles(250000);

    LcdInitMacro[3 * 6 + 5] |= BIT3;
    LcdInitMacro[3 * 6 + 5] &= ~BIT0;
    halLcdSendCommand(&LcdInitMacro[3 * 6]); // R03 Power control
}

void halLcdInit(void)
{
    volatile unsigned int i = 0;

    LCD_CS_RST_OUT |= LCD_CS_PIN | LCD_RESET_PIN;
    LCD_CS_RST_DIR |= LCD_CS_PIN | LCD_RESET_PIN;

    LCD_BACKLT_SEL |= LCD_BACKLIGHT_PIN;

    LCD_CS_RST_OUT &= ~LCD_RESET_PIN;              // Reset LCD
    __delay_cycles(0x47FF);                        //Reset Pulse
    LCD_CS_RST_OUT |= LCD_RESET_PIN;

    // UCLK,MOSI setup, SOMI cleared
    LCD_SPI_SEL |= LCD_MOSI_PIN + LCD_CLK_PIN;
    LCD_SPI_SEL &= ~LCD_MISO_PIN;
    LCD_SPI_DIR &= ~(LCD_MISO_PIN + LCD_MOSI_PIN); // Pin direction controlled by module,
                                                   // Set both pins to input as default

    // Initialize the USCI_B2 module for SPI operation
    UCB2CTL1 = UCSWRST;                            // Hold USCI in SW reset mode while configuring
                                                   // it
    UCB2CTL0 = UCMST + UCSYNC + UCCKPL + UCMSB;    // 3-pin, 8-bit SPI master
    UCB2CTL1 |= UCSSEL_2;                          // SMCLK
    UCB2BR0 = 8;                                   // Note: Do not exceed D/S spec for UCLK!
    UCB2BR1 = 0;
    UCB2CTL1 &= ~UCSWRST;                          // Release USCI state machine
    UCB2IFG &= ~UCRXIFG;

    // Wake-up the LCD as per datasheet specifications
    halLcdActive();

    // LCD Initialization Routine Using Predefined Macros
    halLcdSendCommand(&LcdInitMacro[1 * 6]);
    halLcdSendCommand(&LcdInitMacro[2 * 6]);
    halLcdSendCommand(&LcdInitMacro[4 * 6]);
    halLcdSendCommand(&LcdInitMacro[5 * 6]);
    halLcdSendCommand(&LcdInitMacro[6 * 6]);
    halLcdSendCommand(&LcdInitMacro[7 * 6]);

}


//Sends 6 bytes of data to the LCD
// Puts the LCD into active mode.


void halLcdSetAddress(int Address)
{
    int temp;

    Draw_Block_Address_Macro[4] = Address >> 8;
    Draw_Block_Address_Macro[5] = Address & 0xFF;
    halLcdSendCommand(Draw_Block_Address_Macro);
    LcdAddress = Address;
    temp = Address >> 5;                     // Divided by 0x20
    temp = temp + (temp << 4);
    //Multiplied by (1+16) and added by the offset
    LcdTableAddress = temp + (Address & 0x1F);
}


int halLcdReadBlock(unsigned int Address)
{
    int i = 0, Value = 0, ReadData[7];

    halLcdSetAddress(Address);
    halLcdSendCommand(Read_Block_Address_Macro);

    LCD_CS_RST_OUT &= ~LCD_CS_PIN;          // start transfer CS=0
    UCB2TXBUF = 0x77;                       // Transmit first character 0x77

    while (!(UCB2IFG & UCTXIFG)) ;
    while (UCB2STAT & UCBUSY) ;

    //Read 5 dummies values and 2 valid address data
    LCD_SPI_SEL &= ~LCD_MOSI_PIN;           //Change SPI2C Dir
    LCD_SPI_SEL |= LCD_MISO_PIN;

    for (i = 0; i < 7; i++)
    {
        UCB2IFG &= ~UCRXIFG;
        UCB2TXBUF = 1;                      // load dummy byte 1 for clk
        while (!(UCB2IFG & UCRXIFG)) ;
        ReadData[i] = UCB2RXBUF;
    }
    LCD_CS_RST_OUT |= LCD_CS_PIN;           // Stop Transfer CS = 1

    LCD_SPI_SEL |= LCD_MOSI_PIN;            //Change SPI2C Dir
    LCD_SPI_SEL &= ~LCD_MISO_PIN;
    LCD_CS_RST_DIR |= LCD_MOSI_PIN + LCD_CLK_PIN;
    LCD_CS_RST_DIR &= ~LCD_MISO_PIN;

    Value = (ReadData[5] << 8) + ReadData[6];
    return Value;
}
void halLcdDrawCurrentBlock(unsigned int Value)
{
    int temp;

    Draw_Block_Value_Macro[4] = Value >> 8;
    Draw_Block_Value_Macro[5] = Value & 0xFF;
  // halLcdReadBlock(LcdTableAddress) = Value;

    halLcdSendCommand(Draw_Block_Value_Macro);

    LcdAddress++;
    temp = LcdAddress >> 5;                 // Divided by 0x20
    temp = temp + (temp << 4);
    // Multiplied by (1+16) and added by the offset
    LcdTableAddress = temp + (LcdAddress & 0x1F);

    // If LcdAddress gets off the right edge, move to next line
    if ((LcdAddress & 0x1F) > 0x11)
        halLcdSetAddress((LcdAddress & 0xFFE0) + 0x20);
    if (LcdAddress == LCD_Size)
        halLcdSetAddress(0);
}

void halLcdDrawBlock(unsigned int Address, unsigned int Value)
{
    halLcdSetAddress(Address);
    halLcdDrawCurrentBlock(Value);
}

void halLcdPrint(char String[], unsigned char TextStyle)
{
    int i, j, Counter = 0, BlockValue;
    int Address, LCD_MEM_Add, ActualAddress;
    int temp;
    char LookUpChar;

    ActualAddress = LcdAddress;
    Counter =  LcdAddress & 0x1F;
    i = 0;

    while (String[i] != 0)                  // Stop on null character
    {
        LookUpChar = fonts_lookup[String[i]];

        for (j = 0; j < FONT_HEIGHT; j++)
        {
            Address = ActualAddress + j * 0x20;
            temp = Address >> 5;
            temp += (temp << 4);

            LCD_MEM_Add = temp + (Address & 0x1F);

            BlockValue = halLcdReadBlock(LCD_MEM_Add);

            if (TextStyle & GRAYSCALE_TEXT)
            {
                if (TextStyle & INVERT_TEXT)
                    if (TextStyle & OVERWRITE_TEXT)
                        BlockValue = 0xAAAA - GrayScale_fonts[LookUpChar * (FONT_HEIGHT + 1) + j];
                    else
                        BlockValue |= 0xAAAA - GrayScale_fonts[LookUpChar * (FONT_HEIGHT + 1) + j];
                else
                if (TextStyle & OVERWRITE_TEXT)
                    BlockValue = GrayScale_fonts[LookUpChar * (FONT_HEIGHT + 1) + j];
                else
                    BlockValue |= GrayScale_fonts[LookUpChar * (FONT_HEIGHT + 1) + j];
            }
            else
            {
                if (TextStyle & INVERT_TEXT)
                    if (TextStyle & OVERWRITE_TEXT)
                        BlockValue = 0xFFFF - fonts[LookUpChar * 13 + j];
                    else
                        BlockValue = 0xFFFF - fonts[LookUpChar * 13 + j];

                else
                if (TextStyle & OVERWRITE_TEXT)
                    BlockValue = fonts[LookUpChar * (FONT_HEIGHT + 1) + j];
                else
                    BlockValue = fonts[LookUpChar * (FONT_HEIGHT + 1) + j];
            }
            halLcdDrawBlock(Address, BlockValue);
        }

        Counter++;
        if (Counter == 17)
        {
            Counter = 0;
            ActualAddress += 0x20 * FONT_HEIGHT  - 16;
            if (ActualAddress > LCD_Last_Pixel - 0x20 * FONT_HEIGHT)
                ActualAddress = 0;
        }
        else
            ActualAddress++;
        i++;
    }
    halLcdSetAddress(ActualAddress);

}

void halLcdPrintLine(char String[], unsigned char Line, unsigned char TextStyle)
{
    int temp;

    temp = Line * FONT_HEIGHT;
    halLcdSetAddress(temp << 5);            // 0x20 = 2^5
    halLcdPrint(String, TextStyle);
}

void halLcdClearScreen(void)
{
    int i, j, k, Current_Location = 0;

    halLcdSetAddress(0);

    for (i = 0; i < 110; i++)
    {
        //prepare to send image
        LCD_CS_RST_OUT &= ~LCD_CS_PIN;             //CS = 0 --> Start Transfer
        for (k = 0; k < 3; k++)
        {
            while (!(UCB2IFG & UCTXIFG)) ;         // Wait for TXIFG
            UCB2TXBUF = Draw_Block_Value_Macro[k]; // Load data
        }
        while (UCB2STAT & UCBUSY) ;
        LCD_CS_RST_OUT |= LCD_CS_PIN;              //CS = 1 --> Stop Transfer
        LCD_CS_RST_OUT &= ~LCD_CS_PIN;             //CS = 0 --> Start Transfer
        while (!(UCB2IFG & UCTXIFG)) ;             // Wait for TXIFG
        UCB2TXBUF = Draw_Block_Value_Macro[3];     // Load data

        //send blank line
        for (j = 0; j < 17; j++)
        {
        	//halLcdReadBlock(LcdTableAddress++) = 0x00;
            while (!(UCB2IFG & UCTXIFG)) ;         // Wait for TXIFG
            UCB2TXBUF = 0x00;                      // Load data
            while (!(UCB2IFG & UCTXIFG)) ;         // Wait for TXIFG
            UCB2TXBUF = 0x00;                      // Load data
        }
        //Clear the partially visible block at the edge of the screen
        while (!(UCB2IFG & UCTXIFG)) ;             // Wait for TXIFG
        UCB2TXBUF = 0x00;                          // Load data
        while (!(UCB2IFG & UCTXIFG)) ;             // Wait for TXIFG
        UCB2TXBUF = 0x00;                          // Load data
        while (UCB2STAT & UCBUSY) ;
        LCD_CS_RST_OUT |= LCD_CS_PIN;              //CS = 1 --> Stop Transfer

        Current_Location += 0x20;
        halLcdSetAddress(Current_Location);
    }

    halLcdSetAddress(0);
}

void PrintVal(void){
	halLcdPrintLine("       568",0,0x00);halLcdClearScreen();
	halLcdPrintLine("         568",1,0x00); halLcdClearScreen();
	halLcdPrintLine("          568",2,0x00); 	halLcdClearScreen();
	halLcdPrintLine("            568",3,0x00);halLcdClearScreen();
	halLcdPrintLine("              568",4,0x00); 	halLcdClearScreen();
	halLcdPrintLine("            568",5,0x00); 	halLcdClearScreen();
	halLcdPrintLine("          568",6,0x00); 	halLcdClearScreen();
	halLcdPrintLine("         568",7,0x00); 	halLcdClearScreen();
	halLcdPrintLine("       568",8,0x00); 	halLcdClearScreen();

	halLcdPrintLine("     568",7,0x00); halLcdClearScreen();
	halLcdPrintLine("   568",6,0x00); 	halLcdClearScreen();
	halLcdPrintLine(" 568",5,0x00);halLcdClearScreen();
	halLcdPrintLine("568",4,0x00); 	halLcdClearScreen();
	halLcdPrintLine("  568",3,0x00); 	halLcdClearScreen();
	halLcdPrintLine("    568",2,0x00); 	halLcdClearScreen();
	halLcdPrintLine("      568",1,0x00); 	halLcdClearScreen();
	halLcdPrintLine("       568",0,0x00); 	halLcdClearScreen();

}

int main(void) {
    WDTCTL = WDTPW | WDTHOLD;	// Stop watchdog timer

//Configure switch S1 and S2
	P2SEL &= 0x3F ;//I/O Function 0011 1111=0x3F
	P2DIR &= 0x3F; //P2.6 as input
	P2REN |= 0xC0; //Enable pull resistor
	P2OUT |= 0xC0; //Enable Pull-Up resistor
	P2IE |=  0xC0;   // Enable Port 2 interrupt registers

	// Configure Accelerometer and ADC
		     		     	  P6SEL |= 0x06;                            // P6.1  and P 6.2 ADC option select
		     		     	  P6DIR |= 0x01;                            // P6.0 output -- power to Accelero
		     		     	  P6OUT |=0x01;                             // Switch on the Accelerometer


	P9DIR = 0x19;//Master
	P9SEL = 0x39;

	UCA1CTL1 |= UCSWRST+ UCSSEL__SMCLK; // Reset and set to SMCLK
	// Configure ADC

		     	UCSCTL8 |= MODOSCREQEN;      // need to figure
		     	  ADC12CTL0 = ADC12SHT02 + ADC12ON + ADC12MSC ;         // Sampling time, ADC12 on , Enable Multiple conversion
		     	  ADC12CTL1 = ADC12SHP + ADC12CONSEQ_1 + ADC12SSEL_0;                     // Use sampling timer

		     	  ADC12MCTL0 = ADC12INCH_1; // get X value
		     	  ADC12MCTL1 = ADC12INCH_2; // get Y value

	 __bis_SR_register(GIE); // Enable global interrupts
	halLcdInit();
	halLcdClearScreen();
	    while(1)
	    {PrintVal();}

}


